<?php
session_start();
require '../../vendor/autoload.php'; // Adjust path if needed
require '../../Mailer.php'; // Adjust path if needed
include_once __DIR__ . '/../../database/conection_db.php';
$otpSent = false;
$otpVerified = false;
$error = '';
$success = '';  

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle OTP sending
    if (isset($_POST['send_otp'])) {
        $email = $_POST['email'];
        $name = isset($_POST['name']) ? $_POST['name'] : '';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Please enter a valid email address.";
        } else {
            $otp = rand(100000, 999999);
            $_SESSION['signup_otp'] = $otp;
            $_SESSION['signup_email'] = $email;

            // Use Mailer.php function
            $result = sendOtpMail($email, $name, $otp);
            if ($result === true) {
                $otpSent = true;
                $success = "OTP sent to your email!";
            } else {
                $error = "Message could not be sent. Mailer Error: $result";
            }
        }
    }

    // Handle OTP verification
if (isset($_POST['verify_otp'])) {
    $userOtp = $_POST['otp'];
    if ($userOtp == $_SESSION['signup_otp']) {
        $otpVerified = true;
        $_SESSION['otp_verified'] = true; // <-- THIS FIXES YOUR ISSUE
        $success = "OTP verified successfully!";
    } else {
        $error = "Invalid OTP. Please try again.";
    }
}
    // Handle registration
    if (isset($_POST['register'])) {
        if (isset($_SESSION['otp_verified']) && $_SESSION['otp_verified'] === true) {
            // Create upload directories if they don't exist
            $prcUploadDir = '../../uploads/prc/';
            $resumeUploadDir = '../../uploads/resume/';
            
            if (!file_exists($prcUploadDir)) {
                mkdir($prcUploadDir, 0777, true);
            }
            if (!file_exists($resumeUploadDir)) {
                mkdir($resumeUploadDir, 0777, true);
            }

            // Handle file uploads (PRC ID and Resume)
            $prcIdPath = '';
            $resumePath = '';
            $uploadError = false;

            if (isset($_FILES['prc_id']) && $_FILES['prc_id']['error'] == UPLOAD_ERR_OK) {
                $prcFileName = 'prc_' . time() . '_' . basename($_FILES['prc_id']['name']);
                $prcIdPath = $prcUploadDir . $prcFileName;
                
                // Validate file type
                $allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];
                if (!in_array($_FILES['prc_id']['type'], $allowedTypes)) {
                    $error = "Invalid file type for PRC ID. Please upload PDF, JPEG, or PNG files only.";
                    $uploadError = true;
                } else {
                    if (!move_uploaded_file($_FILES['prc_id']['tmp_name'], $prcIdPath)) {
                        $error = "Failed to upload PRC ID. Please try again.";
                        $uploadError = true;
                    }
                }
            }

            if (!$uploadError && isset($_FILES['resume']) && $_FILES['resume']['error'] == UPLOAD_ERR_OK) {
                $resumeFileName = 'resume_' . time() . '_' . basename($_FILES['resume']['name']);
                $resumePath = $resumeUploadDir . $resumeFileName;
                
                // Validate file type
                $allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
                if (!in_array($_FILES['resume']['type'], $allowedTypes)) {
                    $error = "Invalid file type for Resume. Please upload PDF or Word documents only.";
                    $uploadError = true;
                } else {
                    if (!move_uploaded_file($_FILES['resume']['tmp_name'], $resumePath)) {
                        $error = "Failed to upload Resume. Please try again.";
                        $uploadError = true;
                    }
                }
            }
                if (!$uploadError) {
                    // Get form data
                    $name = $_POST['username'];
                    $gender = $_POST['gender'];
                    $email = $_POST['email'];
                    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                    $dob = $_POST['dob'];
                    $contact = $_POST['contact'];
                    $license = $_POST['license'];
                    $specialization = $_POST['specialization']; // <-- add this line

                    // Insert into database
                    $stmt = $conn->prepare("INSERT INTO doctors (Username, Gender, Email, Password, Birthdate, ContactNumber, License, Specialization, Status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $status = 'Pending';
                    $stmt->bind_param("sssssssss", $name, $gender, $email, $password, $dob, $contact, $license, $specialization, $status);

                    if ($stmt->execute()) {
                        $success = "Registration successful!";
                        unset($_SESSION['signup_otp'], $_SESSION['signup_email'], $_SESSION['signup_name'], $_SESSION['otp_verified']);
                        header("Location: LogForm.php");
                        exit;
                    } else {
                        $error = "Database error: " . $conn->error;
                    }
                    $stmt->close();
                    $conn->close();
                }
                        } else {
                            $error = "Please verify your OTP before registering.";
                        }
                    }
                }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor Sign Up - EMed Consultation</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(120deg, #e0ffe0 0%, #d0f5df 100%);
            min-height: 100vh;
        }
        .signup-card {
            border-radius: 1.5rem;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.15);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .signup-card:hover {
            transform: translateY(-5px) scale(1.01);
            box-shadow: 0 16px 40px 0 rgba(31, 38, 135, 0.18);
        }
        .form-control:focus, .form-check-input:focus {
            border-color: #28a745;
            box-shadow: 0 0 0 0.15rem rgba(40,167,69,.15);
        }
        .btn-primary, .btn-success {
            background-color: #43c97e !important;
            border-color: #43c97e !important;
            transition: background 0.2s, transform 0.2s;
            color: #fff !important;
        }
        .btn-primary:hover, .btn-success:hover {
            background: #2eb872 !important;
            border-color: #2eb872 !important;
            transform: scale(1.04);
            color: #fff !important;
        }
        .form-check-input:checked {
            background-color: #43c97e;
            border-color: #43c97e;
        }
        .fw-bold,
        .text-decoration-none {
            color: #14532d !important;
        }
    </style>
</head>
<body>
<div class="container py-5">
    <div class="row justify-content-center align-items-center">
        <div class="col-lg-6">
            <div class="signup-card bg-white shadow-lg p-4 position-relative">
                <a href="../../Homepage.php  " class="btn-close position-absolute top-0 end-0 m-3" aria-label="Close" style="z-index:2;"></a>
                <div class="text-center mb-4">
                    <img src="../../Images/Signup.png" alt="Sign Up" class="mb-3" style="width:120px;">
                    <h2 class="mb-2" style="color: #2eb872; font-weight: bold">Doctor Sign Up</h2>
                    <p class="text-muted mb-0">Join EMed Consultation as a Doctor</p>
                </div>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?= htmlspecialchars(string: $error) ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="alert alert-success"><?= htmlspecialchars(string: $success) ?></div>
                <?php endif; ?>
                <form method="post" autocomplete="off" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input type="text" name="username" class="form-control" required value="<?= isset($_POST['name']) ? htmlspecialchars($_POST['name']) : '' ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Contact Number</label>
                        <input type="text" name="contact" class="form-control" required value="<?= isset($_POST['contact']) ? htmlspecialchars($_POST['contact']) : '' ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Gender</label>
                        <div class="d-flex gap-3">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" id="genderMale" value="Male" <?= (isset($_POST['gender']) && $_POST['gender'] == 'Male') ? 'checked' : '' ?> required>
                                <label class="form-check-label" for="genderMale">Male</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" id="genderFemale" value="Female" <?= (isset($_POST['gender']) && $_POST['gender'] == 'Female') ? 'checked' : '' ?> required>
                                <label class="form-check-label" for="genderFemale">Female</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" id="genderOther" value="Other" <?= (isset($_POST['gender']) && $_POST['gender'] == 'Other') ? 'checked' : '' ?> required>
                                <label class="form-check-label" for="genderOther">Other</label>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <div class="input-group">
                            <input type="email" name="email" class="form-control" required value="<?= isset($_SESSION['signup_email']) ? htmlspecialchars($_SESSION['signup_email']) : '' ?>" <?= $otpSent ? 'readonly' : '' ?>>
                            <button type="submit" name="send_otp" class="btn btn-primary" <?= $otpSent ? 'disabled' : '' ?>>Send OTP</button>
                        </div>
                    </div>
                    <?php if ($otpSent && !$otpVerified): ?>
                        <div class="mb-3">
                            <label class="form-label">Enter OTP</label>
                            <div class="input-group">
                                <input type="text" name="otp" maxlength="6" class="form-control" required>
                                <button type="submit" name="verify_otp" class="btn btn-success">Verify OTP</button>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="mb-3 position-relative">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <input type="password" name="password" id="password" class="form-control" required minlength="8">
                    </div>
                </div>
                    <div class="mb-3">
                        <label class="form-label">Date of Birth</label>
                        <input type="date" name="dob" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Medical License Number</label>
                        <input type="text" name="license" class="form-control" required value="<?= isset($_POST['license']) ? htmlspecialchars($_POST['license']) : '' ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Specialization</label>
                        <select name="specialization" class="form-control" required>
                            <option value="">Select specialization</option>
                            <option value="Pediatrics" <?= (isset($_POST['specialization']) && $_POST['specialization'] == 'Pediatrics') ? 'selected' : '' ?>>Pediatrics</option>
                            <option value="Neurology" <?= (isset($_POST['specialization']) && $_POST['specialization'] == 'Neurology') ? 'selected' : '' ?>>Neurology</option>
                            <option value="Dermatology" <?= (isset($_POST['specialization']) && $_POST['specialization'] == 'Dermatology') ? 'selected' : '' ?>>Dermatology</option>
                            <option value="OBGYN" <?= (isset($_POST['specialization']) && $_POST['specialization'] == 'OBGYN') ? 'selected' : '' ?>>OBGYN</option>
                            <option value="Gastroenterology" <?= (isset($_POST['specialization']) && $_POST['specialization'] == 'Gastroenterology') ? 'selected' : '' ?>>Gastroenterology</option>
                            <option value="Cardiology" <?= (isset($_POST['specialization']) && $_POST['specialization'] == 'Cardiology') ? 'selected' : '' ?>>Cardiology</option>
                            <option value="ENT-HNS" <?= (isset($_POST['specialization']) && $_POST['specialization'] == 'ENT-HNS') ? 'selected' : '' ?>>ENT-HNS</option>
                            <option value="Ophthalmology" <?= (isset($_POST['specialization']) && $_POST['specialization'] == 'Ophthalmology') ? 'selected' : '' ?>>Ophthalmology</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Upload PRC ID</label>
                        <input type="file" name="prc_id" class="form-control" accept="image/*,application/pdf" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Upload Resume</label>
                        <input type="file" name="resume" class="form-control" accept="application/pdf,.doc,.docx" required>
                    </div>
                    <input type="hidden" name="otp_verified" value="<?= $otpVerified ? '1' : '0' ?>">
                    <button type="submit" name="register" class="btn btn-primary w-100 py-2" <?= !$otpVerified ? 'disabled' : '' ?>>Register Now</button>
                </form>
                <p class="text-center mt-3 mb-0">Already registered? <a href="LogForm.php" class="text-decoration-none" style="color:#43c97e;">Log in</a></p>
            </div>
        </div>
    </div>
</div>


<!-- Bootstrap JS (optional, for some components) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>