<?php
include_once __DIR__ . '/../database/conection_db.php';

$id = $_POST['id'] ?? '';
$action = $_POST['action'] ?? '';
$reason = $_POST['reason'] ?? '';

if (!$id || !$action) {
    echo "Invalid request.";
    exit;
}

if ($action === 'accept') {
    $stmt = $conn->prepare("UPDATE appointments SET status='Accepted' WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    echo "Appointment accepted.";
} elseif ($action === 'reject') {
    $stmt = $conn->prepare("UPDATE appointments SET status='Rejected' WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    echo "Appointment rejected.";
} elseif ($action === 'refer') {
    $stmt = $conn->prepare("UPDATE appointments SET status='Referred', refer_to=? WHERE id=?");
    $stmt->bind_param("si", $reason, $id);
    $stmt->execute();
    echo "Appointment referred to $reason.";
} else {
    echo "Unknown action.";
}
?>