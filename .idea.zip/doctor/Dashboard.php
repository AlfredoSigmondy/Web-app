<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Dashboard - eMedConnect</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f8fafc; }
        .dashboard-card {
            border-radius: 16px;
            box-shadow: 0 2px 16px #0001;
            background: #fff;
            padding: 32px 24px;
            margin-bottom: 24px;
        }
        .dashboard-title {
            color: #14532d;
            font-weight: 700;
            margin-bottom: 24px;
        }
        .stat-value {
            font-size: 2.2rem;
            font-weight: 700;
            color: #2eb872;
        }
        .stat-label {
            color: #888;
            font-size: 1.1rem;
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <?php include_once __DIR__ . '/../SideBar/DSidebar.php'; ?>
        <div class="flex-grow-1 p-4">
            <h2 class="dashboard-title mb-4">Welcome, Doctor!</h2>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="dashboard-card text-center">
                        <div class="stat-value">
                            <?php
                            include_once __DIR__ . '/../database/conection_db.php';
                            $result = $conn->query("SELECT COUNT(*) as total FROM patient");
                            $row = $result ? $result->fetch_assoc() : ['total' => 0];
                            echo $row['total'];
                            ?>
                        </div>
                        <div class="stat-label">Total Patients</div>
                        <i class="bi bi-people" style="font-size:2rem;color:#43c97e;"></i>
                    </div>
                </div>
                <div class="col-md-4">
                    <div id="appointmentsCard" class="dashboard-card text-center" style="cursor:pointer;" data-bs-toggle="modal" data-bs-target="#appointmentsModal">
                        <div class="stat-value">
                            <?php
                                $query = "SELECT COUNT(*) AS total FROM appointments WHERE doctor_id = ''";
                                $result = $conn->query($query);
                                $row = $result->fetch_assoc();
                                echo $row['total'];
                            ?>
                        </div>
                        <div class="stat-label">My Appointments</div>
                        <i class="bi bi-calendar-event" style="font-size:2rem;color:#43c97e;"></i>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dashboard-card text-center">
                        <div class="stat-value">
                            <?php
                            $result = $conn->query("SELECT COUNT(*) as total FROM doctors  WHERE Status = 'Approved'");
                            $row = $result ? $result->fetch_assoc() : ['total' => 0];
                            echo $row['total'];
                            ?>
                        </div>
                        <div class="stat-label">Doctors (Approved)</div>
                        <i class="bi bi-person-badge" style="font-size:2rem;color:#43c97e;"></i>
                    </div>
                </div>
            </div>
            <div class="dashboard-card mt-4">
                <h5 class="mb-3">Quick Actions</h5>
                <a href="Message.php" class="btn btn-success me-2"><i class="bi bi-chat-dots"></i> Message Patients</a>
            </div>
        </div>
         <?php include_once __DIR__ . '/../SideBar_Right/SidebarRight.html'; ?>
    </div>

    <!-- Appointments Modal -->
    <div class="modal fade" id="appointmentsModal" tabindex="-1" aria-labelledby="appointmentsModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="appointmentsModalLabel">My Appointments</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body" id="appointmentsModalBody">
            <!-- Appointment details will be loaded here -->
          </div>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
document.getElementById('appointmentsCard').addEventListener('click', function() {
    fetch('fetch_appointments.php')
        .then(response => response.text())
        .then(html => {
            document.getElementById('appointmentsModalBody').innerHTML = html;
            var modal = new bootstrap.Modal(document.getElementById('appointmentsModal'));
            modal.show();
        });
});
function handleAppointmentAction(appointmentId, action) {
    let reason = '';
    if (action === 'refer') {
        reason = prompt('Enter the doctor to refer to:');
        if (!reason) return;
    }
    fetch('appointment_action.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `id=${appointmentId}&action=${action}&reason=${encodeURIComponent(reason)}`
    })
    .then(response => response.text())
    .then(msg => {
        alert(msg);
        document.getElementById('appointmentsCard').click(); // Reload appointments
    });
}
</script>
</body>
</html>