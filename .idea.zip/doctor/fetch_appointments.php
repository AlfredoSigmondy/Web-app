<?php
// filepath: c:\Users\Ronian\OneDrive\Desktop\EMed\doctor\fetch_appointments.php
session_start();
include_once __DIR__ . '/../database/conection_db.php';

// Replace with actual doctor ID from session/JWT
$doctor_id = ''; // TODO: get from session or JWT

$query = "SELECT a.id, p.Username, p.Email, p.Birthdate, p.Gender, p.patientId
          FROM appointments a
          JOIN patient p ON a.patient_id = p.PatientID
          WHERE a.doctor_id = ?";   
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $doctor_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<div class='text-center text-muted'>No appointments found.</div>";
} else {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='card mb-3'>
                <div class='card-body'>
                    <h5 class='card-title'>{$row['Name']}</h5>
                    <p class='card-text'>
                        <b>Email:</b> {$row['Email']}<br>
                        <b>Birthdate:</b> {$row['Birthdate']}<br>
                        <b>Gender:</b> {$row['Gender']}<br>
                        <b>Contact:</b> {$row['ContactNumber']}<br>
                        <b>Medical Info:</b> {$row['MedicalInfo']}<br>
                        <b>Date:</b> {$row['date']}
                        
                    </p>
                    <button class='btn btn-success me-2' onclick='handleAppointmentAction({$row['id']}, \"accept\")'>Accept</button>
                    <button class='btn btn-danger me-2' onclick='handleAppointmentAction({$row['id']}, \"reject\")'>Reject</button>
                    <button class='btn btn-warning' onclick='handleAppointmentAction({$row['id']}, \"refer\")'>Refer</button>
                </div>
              </div>";
    }
}
?>