<?php
header('Content-Type: application/json');
include_once __DIR__ . '/../database/conection_db.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors in production
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/availability_errors.log');

$doctorId = $_GET['MedicId'] ?? null;
$year = $_GET['year'] ?? date('Y');
$month = $_GET['month'] ?? date('m');

if (!$doctorId) {
    error_log("Error: Doctor ID is required");
    echo json_encode(['error' => 'Doctor ID is required']);
    exit;
}

try {
    // Verify doctor exists
    $checkDoctor = $conn->prepare("SELECT COUNT(*) FROM doctors WHERE MedicID = ?");
    if (!$checkDoctor) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    $checkDoctor->bind_param("i", $doctorId);
    $checkDoctor->execute();
    if ($checkDoctor->get_result()->fetch_row()[0] == 0) {
        error_log("Error: Invalid Doctor ID: $doctorId");
        echo json_encode(['error' => 'Invalid Doctor ID']);
        exit;
    }

    // Get regular availability
    $availabilityStmt = $conn->prepare("
        SELECT day_of_week, start_time, end_time 
        FROM doctor_availability 
        WHERE doctor_id = ? AND is_recurring = TRUE
        AND (valid_to IS NULL OR valid_to >= CURDATE())
    ");
    if (!$availabilityStmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    $availabilityStmt->bind_param("i", $doctorId);
    if (!$availabilityStmt->execute()) {
        throw new Exception("Execute failed: " . $availabilityStmt->error);
    }
    $regularAvailability = $availabilityStmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Get exceptions
    $exceptionsStmt = $conn->prepare("
        SELECT exception_date AS ExceptionDate, IsAvailable, StartTime, EndTime 
        FROM availability_exceptions 
        WHERE doctor_id = ? 
        AND YEAR(exception_date) = ? 
        AND MONTH(exception_date) = ?
    ");
    if (!$exceptionsStmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    $exceptionsStmt->bind_param("iii", $doctorId, $year, $month);
    if (!$exceptionsStmt->execute()) {
        throw new Exception("Execute failed: " . $exceptionsStmt->error);
    }
    $exceptions = $exceptionsStmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Get existing appointments
    $appointmentsStmt = $conn->prepare("
        SELECT appointment_date, start_time, end_time 
        FROM appointments 
        WHERE doctor_id = ? 
        AND YEAR(appointment_date) = ? 
        AND MONTH(appointment_date) = ?
        AND status IN ('Scheduled', 'Pending')
    ");
    if (!$appointmentsStmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    $appointmentsStmt->bind_param("iii", $doctorId, $year, $month);
    if (!$appointmentsStmt->execute()) {
        throw new Exception("Execute failed: " . $appointmentsStmt->error);
    }
    $appointments = $appointmentsStmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Process available dates and slots
    $availableDates = [];
    $availableSlots = [];

    $startDate = new DateTime("$year-$month-01");
    $endDate = (clone $startDate)->modify('last day of this month');
    $currentDate = new DateTime();
    
    if ($startDate < $currentDate) {
        $startDate = clone $currentDate;
        $startDate->setTime(0, 0, 0);
    }
    
    if ($endDate < $currentDate) {
        $endDate = clone $currentDate;
    }
    
    $interval = new DateInterval('P1D');
    $dateRange = new DatePeriod($startDate, $interval, $endDate->modify('+1 day'));

    foreach ($dateRange as $date) {
        $dateStr = $date->format('Y-m-d');
        $dayOfWeek = $date->format('w');

        // Check exceptions
        $exception = array_filter($exceptions, function($e) use ($dateStr) {
            return $e['ExceptionDate'] == $dateStr;
        });
        $exception = reset($exception);

        if ($exception) {
            if ($exception['IsAvailable'] && $exception['StartTime'] && $exception['EndTime']) {
                $availableDates[] = $dateStr;
                $availableSlots[$dateStr] = generateTimeSlots($exception['StartTime'], $exception['EndTime']);
            }
            continue;
        }

        // Check regular availability
        $dayAvailability = array_filter($regularAvailability, function($a) use ($dayOfWeek) {
            return $a['day_of_week'] == $dayOfWeek;
        });

        foreach ($dayAvailability as $availability) {
            if ($availability['start_time'] && $availability['end_time']) {
                $availableDates[] = $dateStr;
                $availableSlots[$dateStr] = generateTimeSlots($availability['start_time'], $availability['end_time']);
            }
        }
    }

    // Remove booked slots
    foreach ($appointments as $appointment) {
        $dateStr = $appointment['appointment_date'];
        if (isset($availableSlots[$dateStr])) {
            $availableSlots[$dateStr] = array_filter($availableSlots[$dateStr], function($slot) use ($appointment) {
                return $slot != $appointment['start_time'];
            });
            $availableSlots[$dateStr] = array_values($availableSlots[$dateStr]);
            if (empty($availableSlots[$dateStr])) {
                $availableDates = array_diff($availableDates, [$dateStr]);
                unset($availableSlots[$dateStr]);
            }
        }
    }

    // Response
    echo json_encode([
        'dates' => array_values($availableDates),
        'slots' => $availableSlots,
        'year' => (int)$year,
        'month' => (int)$month,
        'month_name' => $startDate->format('F'),
        'prev_year' => (int)(clone $startDate)->modify('-1 month')->format('Y'),
        'prev_month' => (int)(clone $startDate)->modify('-1 month')->format('n'),
        'nextthext_year' => (int)(clone $startDate)->modify('+1 month')->format('Y'),
        'next_month' => (int)(clone $startDate)->modify('+1 month')->format('n')
    ]);

} catch (Exception $e) {
    error_log("Error in get_available_dates.php: " . $e->getMessage() . "\n" . $e->getTraceAsString());
    echo json_encode([
        'error' => 'Server error: ' . $e->getMessage(),
        'trace' => $e->getTrace()
    ]);
}

function generateTimeSlots($startTime, $endTime) {
    $slots = [];
    try {
        $start = new DateTime($startTime);
        $end = new DateTime($endTime);
        $interval = new DateInterval('PT30M');
        
        $current = clone $start;
        while ($current < $end) {
            $slots[] = $current->format('H:i');
            $current->add($interval);
        }
    } catch (Exception $e) {
        error_log("Error generating time slots: " . $e->getMessage());
    }
    return $slots;
}
?>