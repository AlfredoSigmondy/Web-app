<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Consultation - eMedConnect</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="Consultation.css">
  <style>
    .overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: none; z-index: 999; }
    .overlay.active { display: flex; justify-content: center; align-items: center; }
    .form-modal { background: #fff; padding: 2rem; border-radius: 10px; max-width: 600px; width: 100%; position: relative; }
    .calendar-date { cursor: pointer; padding: 5px 10px; border-radius: 5px; margin: 2px; display: inline-block; background-color: #e9f7ef; }
    .calendar-date.active { background-color: #198754; color: #fff; }
    .calendar-date .remove-btn { margin-left: 6px; color: red; cursor: pointer; font-weight: bold; }
    .doctor-info-card { background: #f8f9fa; padding: 1rem; border-radius: 10px; margin-top: 1rem; display: none; }
    .selectable-specialization.selected { border: 2px solid #198754; border-radius: 10px; }
    .filter-dropdown { position: absolute; right: 0; top: 100%; background: white; padding: 1rem; border-radius: 5px; box-shadow: 0 0 10px rgba(0,0,0,0.1); z-index: 100; display: none; }
    .filter-dropdown.active { display: block; }
    .specialization-icon img { width: 50px; height: 50px; object-fit: cover; }
    .calendar-day { cursor: pointer; padding: 10px; border-radius: 5px; margin: 2px; display: inline-block; text-align: center; }
    .calendar-day.available { background-color: #e9f7ef; }
    .calendar-day.selected { background-color: #198754; color: #fff; }
    .time-slot { cursor: pointer; padding: 8px 12px; border-radius: 5px; margin: 2px; display: inline-block; background-color: #e9f7ef; }
    .time-slot.selected { background-color: #198754; color: #fff; }
  </style>
</head>
<body>
<div class="d-flex" style="min-height: 100vh;">
  <?php include_once __DIR__ . '/../SideBar/Sidebar.php'; ?>
  <div class="flex-grow-1 main-content p-3">

    <!-- Top Bar -->
    <div class="d-flex align-items-center mb-4 position-relative">
      <input type="text" class="form-control search-bar" placeholder="Search Here" id="searchInput">
      <button class="btn btn-light ms-2" id="filterBtn"><i class="bi bi-sliders"></i></button>
      <div class="filter-dropdown" id="filterDropdown">
        <div class="mb-2"><strong>Filter By:</strong></div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="Pediatrics" id="filterPediatrics" checked>
          <label class="form-check-label" for="filterPediatrics">Pediatrics</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="Neurology" id="filterNeurology" checked>
          <label class="form-check-label" for="filterNeurology">Neurology</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="Dermatology" id="filterDermatology" checked>
          <label class="form-check-label" for="filterDermatology">Dermatology</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="OBGYN" id="filterOBGYN" checked>
          <label class="form-check-label" for="filterOBGYN">OBGYN</label>
        </div>
        <button class="btn btn-sm btn-primary mt-2" id="applyFilters">Apply</button>
      </div>
      <button class="btn btn-light ms-2"><i class="bi bi-bell"></i></button>
    </div>

    <h5 class="fw-bold mb-2">Find specialization</h5>
    <div class="mb-2">Select:</div>

    <!-- Specializations -->
    <div class="specialization-grid p-4 mb-4">
      <div class="row g-4" id="specializationsContainer">
        <?php
        $specializations = [
          "Pediatrics", "Neurology", "Dermatology", "OBGYN",
          "Gastroenterology", "Cardiology", "ENT-HNS", "Ophthalmology"
        ];
        foreach ($specializations as $spec): ?>
          <div class="col-6 col-md-3 text-center specialization-item" data-specialization="<?= htmlspecialchars($spec) ?>">
            <div class="specialization-icon mx-auto mb-2 selectable-specialization"
                 data-specialization="<?= htmlspecialchars($spec) ?>"
                 onclick="selectSpecialization(this)">
              <img src="../Images/profile-user.png" class="img-fluid">
            </div>
            <div><?= $spec ?></div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <button class="button btn-green w-100 py-2 mb-4 fw-bold" onclick="toggleForm()">Make an appointment</button>

    <!-- Appointment Form Modal -->
    <div id="appointmentOverlay" class="overlay">
      <div id="appointmentForm" class="form-modal">
        <form method="post" action="book_appointment.php" class="appointment-form" id="appointmentBookingForm">
          <h4 class="mb-3">Book an Appointment</h4>
          <div class="mb-3">
            <label>Specialization:</label>
            <span id="selectedSpecializationText" class="badge bg-success ms-2"></span>
          </div>
          <div class="mb-3">
            <label for="doctor">Choose Doctor:</label>
            <select class="form-control" id="doctor" name="doctor" onchange="showDoctorInfo(this.value)" required>
              <option value="" disabled selected>Select a doctor</option>
            </select>
          </div>
          <div id="doctorDetails" class="doctor-info-card">
            <h6 id="docName">Dr. </h6>
            <p><strong>Email:</strong> <span id="docEmail"></span></p>
            <p><strong>Contact:</strong> <span id="docContact"></span></p>
            <p><strong>Available Dates:</strong></p>
            <div id="calendarDates"></div>
          </div>
          <input type="hidden" name="selected_date" id="selectedDateInput">
          <div class="mb-3">
            <label for="name">Your Name:</label>
            <input type="text" class="form-control" name="name" id="name" required>
          </div>
          <div class="mb-3">
            <label for="notes">Additional Notes:</label>
            <textarea class="form-control" name="notes" id="notes" rows="3"></textarea>
          </div>
          <div class="d-flex justify-content-between">
            <button type="submit" class="btn btn-success">Submit</button>
            <button type="button" class="btn btn-danger" onclick="toggleForm(true)">Close</button>
          </div>
          <div id="formError" class="alert alert-danger mt-3" style="display: none;"></div>
        </form>
      </div>
    </div>

    <!-- Confirmation Modal -->
    <div class="modal fade" id="confirmModal" tabindex="-1" aria-labelledby="confirmModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="confirmModalLabel">Confirm Appointment</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div id="confirmMsg"></div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary" id="confirmBtn">Confirm</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Calendar and Time Slots -->
    <div id="calendarContainer" class="mt-3" style="display: none;">
      <div class="d-flex justify-content-between align-items-center mb-2">
        <h6 class="mb-0" id="calendarMonthYear"></h6>
        <div>
          <button class="btn btn-sm btn-light" id="prevMonthBtn"><i class="bi bi-chevron-left"></i></button>
          <button class="btn btn-sm btn-light" id="nextMonthBtn"><i class="bi bi-chevron-right"></i></button>
        </div>
      </div>
      <div class="d-flex flex-wrap" id="calendarGrid"></div>
      <div class="mt-3" id="timeSlots"></div>
    </div>

  </div>
  <?php include_once __DIR__ . '/../SideBar_Right/SidebarRight.html'; ?>
</div>

<!-- Scripts -->
<script>
let selectedSpecialization = null;
let allSpecializations = ["Pediatrics", "Neurology", "Dermatology", "OBGYN", "Gastroenterology", "Cardiology", "ENT-HNS", "Ophthalmology"];
let availableDates = {}; // { "2025-06-12": ["14:05", "15:10"], ... }
let selectedDate = null;
let selectedTime = null;

// Initialize filters
document.addEventListener('DOMContentLoaded', function() {
  // Filter button toggle
  document.getElementById('filterBtn').addEventListener('click', function() {
    document.getElementById('filterDropdown').classList.toggle('active');
  });

  // Apply filters
  document.getElementById('applyFilters').addEventListener('click', function() {
    applyFilters();
    document.getElementById('filterDropdown').classList.remove('active');
  });

  // Search functionality
  document.getElementById('searchInput').addEventListener('input', function() {
    filterSpecializations();
  });

  // Appointment form submission
  document.getElementById('appointmentBookingForm').addEventListener('submit', function(e) {
    e.preventDefault();
    submitAppointment();
  });

  // Calendar navigation
  document.getElementById('prevMonthBtn').addEventListener('click', function() {
    changeMonth(-1);
  });
  document.getElementById('nextMonthBtn').addEventListener('click', function() {
    changeMonth(1);
  });
});

function applyFilters() {
  const activeFilters = [];
  document.querySelectorAll('#filterDropdown input[type="checkbox"]:checked').forEach(checkbox => {
    activeFilters.push(checkbox.value);
  });
  
  document.querySelectorAll('.specialization-item').forEach(item => {
    const spec = item.getAttribute('data-specialization');
    if (activeFilters.includes(spec)) {
      item.style.display = 'block';
    } else {
      item.style.display = 'none';
    }
  });
}

function filterSpecializations() {
  const searchTerm = document.getElementById('searchInput').value.toLowerCase();
  document.querySelectorAll('.specialization-item').forEach(item => {
    const spec = item.getAttribute('data-specialization').toLowerCase();
    if (spec.includes(searchTerm)) {
      item.style.display = 'block';
    } else {
      item.style.display = 'none';
    }
  });
}

function selectSpecialization(el) {
  document.querySelectorAll('.selectable-specialization').forEach(i => i.classList.remove('selected'));
  el.classList.add('selected');
  selectedSpecialization = el.getAttribute('data-specialization');
}

function toggleForm(close = false) {
  const overlay = document.getElementById('appointmentOverlay');
  if (close) {
    overlay.classList.remove('active');
    return;
  }
  if (!selectedSpecialization) {
    alert('Please select a specialization.');
    return;
  }
  document.getElementById('selectedSpecializationText').textContent = selectedSpecialization;

  fetch(`get_doctors.php?specialization=${encodeURIComponent(selectedSpecialization)}`)
    .then(res => {
      if (!res.ok) {
        throw new Error('Network response was not ok');
      }
      return res.json();
    })
    .then(doctors => {
      const select = document.getElementById('doctor');
      select.innerHTML = '<option value="" disabled selected>Select a doctor</option>';
      
      if (doctors.length === 0) {
        select.innerHTML = '<option disabled selected>No doctors found</option>';
      } else {
        doctors.forEach(doc => {
          const opt = document.createElement('option');
          opt.value = doc.MedicID;
          opt.textContent = doc.Username;
          select.appendChild(opt);
        });
        // Show info for first doctor by default
        if (doctors.length > 0) {
          showDoctorInfo(select.value);
        }
      }
      overlay.classList.add('active');
    })
    .catch(error => {
      console.error('Error fetching doctors:', error);
      alert('Error loading doctors. Please try again.');
    });
}

async function showDoctorInfo(doctorId) {
  if (!doctorId) {
    document.getElementById('doctorDetails').style.display = 'none';
    return;
  }

  try {
    // CORRECTED: Use doctorId instead of docID
    const doctorResponse = await fetch('get_doctor_info.php?doctor_id=' + encodeURIComponent(doctorId));
    if (!doctorResponse.ok) throw new Error('Doctor info fetch failed');
    const doctor = await doctorResponse.json();

    // Update doctor info display
    document.getElementById('doctorDetails').style.display = 'block';
    document.getElementById('docName').textContent = "Dr. " + (doctor.Username);
    document.getElementById('docEmail').textContent = doctor.Email;
    document.getElementById('docContact').textContent = doctor.ContactNumber;

    // Then fetch available dates
    const datesResponse = await fetch(`get_available_dates.php?doctor_id=${doctorId}`);
    if (!datesResponse.ok) throw new Error('Dates fetch failed');
    availableDates = await datesResponse.json();

    renderCalendar();
  } catch (error) {
    console.error('Error fetching doctor info:', error);
    document.getElementById('doctorDetails').style.display = 'block';
    document.getElementById('docName').textContent = "Dr. [Error loading info]";
    document.getElementById('docEmail').textContent = "Error loading contact information";
    document.getElementById('docContact').textContent = "N/A";
    document.getElementById('calendarDates').innerHTML = '<p>Error loading available dates</p>';
  }
}

function renderCalendar() {
  const calendarGrid = document.getElementById('calendarGrid');
  const monthYear = document.getElementById('calendarMonthYear');
  calendarGrid.innerHTML = '';
  monthYear.textContent = '';

  if (!availableDates || Object.keys(availableDates).length === 0) {
    calendarGrid.innerHTML = '<div class="text-muted">No available dates</div>';
    document.getElementById('timeSlots').innerHTML = '';
    return;
  }

  // Get first available date's month/year
  const firstDate = Object.keys(availableDates)[0];
  const dateObj = new Date(firstDate);
  const year = dateObj.getFullYear();
  const month = dateObj.getMonth();
  monthYear.textContent = dateObj.toLocaleString('default', { month: 'long', year: 'numeric' });

  // Build calendar days for the month
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfWeek = new Date(year, month, 1).getDay();
  for (let i = 0; i < firstDayOfWeek; i++) {
    calendarGrid.appendChild(document.createElement('div')); // empty cell
  }
  for (let d = 1; d <= daysInMonth; d++) {
    const dayStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const dayEl = document.createElement('div');
    dayEl.className = 'calendar-day';
    dayEl.textContent = d;
    if (availableDates[dayStr]) {
      dayEl.classList.add('available');
      dayEl.onclick = () => selectDate(dayStr, dayEl);
    }
    if (selectedDate === dayStr) dayEl.classList.add('selected');
    calendarGrid.appendChild(dayEl);
  }
}

function selectDate(dateStr, dayEl) {
  selectedDate = dateStr;
  document.querySelectorAll('.calendar-day').forEach(el => el.classList.remove('selected'));
  dayEl.classList.add('selected');
  renderTimeSlots(dateStr);
}

function renderTimeSlots(dateStr) {
  const timeSlotsDiv = document.getElementById('timeSlots');
  timeSlotsDiv.innerHTML = '';
  selectedTime = null;
  if (!availableDates[dateStr] || availableDates[dateStr].length === 0) {
    timeSlotsDiv.innerHTML = '<span class="text-muted">No time slots</span>';
    return;
  }
  availableDates[dateStr].forEach(time => {
    const slot = document.createElement('span');
    slot.className = 'time-slot';
    slot.textContent = time;
    slot.onclick = () => selectTimeSlot(dateStr, time, slot);
    timeSlotsDiv.appendChild(slot);
  });
}

function selectTimeSlot(dateStr, time, slotEl) {
  selectedTime = time;
  document.querySelectorAll('.time-slot').forEach(el => el.classList.remove('selected'));
  slotEl.classList.add('selected');
  showConfirmModal(dateStr, time);
}

function showConfirmModal(dateStr, time) {
  const confirmMsg = document.getElementById('confirmMsg');
  confirmMsg.innerHTML = `
    <div>You will be notified to begin the consultation on:</div>
    <div class="fw-bold my-2">${new Date(dateStr).toLocaleDateString()}<br>${time} <span style="text-transform:lowercase;">${time >= '12:00' ? 'PM' : 'AM'}</span></div>
    <div class="text-muted" style="font-size:0.9em;">The timing you see is in your local time zone (${Intl.DateTimeFormat().resolvedOptions().timeZone})</div>
  `;
  const confirmModal = new bootstrap.Modal(document.getElementById('confirmModal'));
  confirmModal.show();

  document.getElementById('confirmBtn').onclick = () => {
    document.getElementById('selectedDateInput').value = dateStr + ' ' + time;
    confirmModal.hide();
  };
}

async function submitAppointment() {
  const form = document.getElementById('appointmentBookingForm');
  const formData = new FormData(form);
  const errorElement = document.getElementById('formError');
  
  // Validate form
  if (!formData.get('doctor') || !formData.get('selected_date') || !formData.get('name')) {
    errorElement.textContent = 'Please fill all required fields';
    errorElement.style.display = 'block';
    return;
  }

  try {
    const response = await fetch('book_appointment.php', {
      method: 'POST',
      body: formData
    });

    const result = await response.json();
    
    if (response.ok) {
      alert('Appointment booked successfully!');
      toggleForm(true);
      form.reset();
      errorElement.style.display = 'none';
    } else {
      errorElement.textContent = result.message || 'Error booking appointment';
      errorElement.style.display = 'block';
    }
  } catch (error) {
    console.error('Error:', error);
    errorElement.textContent = 'Network error. Please try again.';
    errorElement.style.display = 'block';
  }
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>