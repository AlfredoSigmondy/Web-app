<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Doctors - eMedConnect</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css" rel="stylesheet">
    <link rel="stylesheet" href="Doctor.css">
    <style>
        .doctor-card {
            background-color: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .doctor-avatar i {
            font-size: 50px;
            color: #198754;
        }
        .doctor-info {
            flex-grow: 1;
        }
        .btn-green {
            background-color: #198754;
            color: white;
            border: none;
            border-radius: 10px;
            padding: 10px 20px;
            font-weight: 500;
        }
        .search-bar {
            flex-grow: 1;
        }
        .main-content {
            overflow-y: auto;
            max-height: 100vh;
            padding: 1rem;
        }
        .time-slot-btn {
            min-width: 80px;
            margin: 5px;
        }
        .time-slot-btn.selected {
            background-color: #198754;
            color: white;
        }
    </style>
</head>
<body>
<div class="d-flex" style="min-height: 100vh;">
    <?php include_once __DIR__ . '/../SideBar/Sidebar.php'; ?>
    <div class="flex-grow-1 main-content">
        <?php
        include_once __DIR__ . '/../database/conection_db.php';
        $search = isset($_GET['search']) ? trim($_GET['search']) : '';
        $limit = 5;
        $page = isset($_GET['page']) ? max((int)$_GET['page'], 1) : 1;
        $offset = ($page - 1) * $limit;

        $countSql = "SELECT COUNT(*) as total FROM doctors" . (!empty($search) ? " WHERE Specialization LIKE '%$search%' OR Username LIKE '%$search%'" : "");
        $countResult = $conn->query($countSql);
        $totalDoctors = $countResult->fetch_assoc()['total'];
        $totalPages = ceil($totalDoctors / $limit);

        $sql = "SELECT MedicID, Username, Email, Specialization, Gender, Birthdate, ContactNumber FROM doctors";
        if (!empty($search)) {
            $sql .= " WHERE Specialization LIKE '%$search%' OR Username LIKE '%$search%'";
        }
        $sql .= " LIMIT $limit OFFSET $offset";
        $result = $conn->query($sql);
        ?>

        <form method="GET" class="d-flex align-items-center mb-4" style="gap: 0.5rem;">
            <input type="text" class="form-control search-bar" name="search" placeholder="Search specialization or doctor name..." value="<?= htmlspecialchars($search) ?>">
            <button class="btn btn-light" type="submit"><i class="bi bi-search"></i></button>
        </form>

        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="doctor-card">
                    <div class="doctor-avatar">
                        <i class="bi bi-person-circle"></i>
                    </div>
                    <div class="doctor-info">
                        <div class="doctor-name fw-bold">Dr. <?= htmlspecialchars($row['Username']) ?></div>
                        <div class="doctor-title text-muted"><?= htmlspecialchars($row['Specialization']) ?></div>
                        <div class="doctor-exp"><?= ($row['Birthdate']) ? (date('Y') - date('Y', strtotime($row['Birthdate']))) . " Years of Experience" : "Experience Unknown" ?></div>
                        <div class="doctor-email text-secondary"><?= htmlspecialchars($row['Email']) ?></div>
                        <div class="doctor-contact">Contact: <?= htmlspecialchars($row['ContactNumber']) ?></div>
                    </div>
                    <button class="btn btn-green book-btn" data-doctor-id="<?= htmlspecialchars($row['MedicID']) ?>" data-bs-toggle="modal" data-bs-target="#bookAppointmentModal">Book Appointment</button>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No doctors found.</p>
        <?php endif; ?>

        <?php if ($totalPages > 1): ?>
            <nav>
                <ul class="pagination justify-content-center mt-4">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                            <a class="page-link" href="?search=<?= urlencode($search) ?>&page=<?= $i ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        <?php endif; ?>
    </div>
    <?php include_once __DIR__ . '/../SideBar_Right/SidebarRight.html'; ?>
</div>

<!-- Appointment Modal -->
<div class="modal fade" id="bookAppointmentModal" tabindex="-1" aria-labelledby="bookAppointmentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="bookAppointmentModalLabel">Book Appointment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="appointmentForm">
                    <input type="hidden" id="doctorId" name="doctor_id">
                    <div class="mb-3">
                        <label for="patientName" class="form-label">Your Name</label>
                        <input type="text" class="form-control" id="patientName" name="patient_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="notes" class="form-label">Reason for Appointment</label>
                        <textarea class="form-control" id="notes" name="notes" rows="4" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="appointmentDate" class="form-label">Select Date</label>
                        <input type="text" class="form-control" id="appointmentDate" name="appointment_date" readonly required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Available Times</label>
                        <div id="timeSlots" class="d-flex flex-wrap gap-2"></div>
                        <input type="hidden" id="startTime" name="start_time" required>
                    </div>
                    <div class="mb-3">
                        <p><strong>Selected:</strong> <span id="selectedDateTime">None</span></p>
                    </div>
                    <button type="submit" class="btn btn-primary" id="submitBtn">Confirm Appointment</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
// Toast notification
function showToast(message, isSuccess = true) {
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white ${isSuccess ? 'bg-success' : 'bg-danger'} border-0`;
    toast.style.position = 'fixed';
    toast.style.bottom = '20px';
    toast.style.right = '20px';
    toast.style.zIndex = '9999';
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    document.body.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    setTimeout(() => toast.remove(), 4000);
}

// Initialize Flatpickr
let flatpickrInstance;
let availableDates = [];
let availableSlots = {};

// Handle Book Appointment button
document.querySelectorAll('.book-btn').forEach(button => {
    button.addEventListener('click', function() {
        const doctorId = this.getAttribute('data-doctor-id');
        document.getElementById('doctorId').value = doctorId;

        // Reset form
        document.getElementById('appointmentForm').reset();
        document.getElementById('timeSlots').innerHTML = '';
        document.getElementById('startTime').value = '';
        document.getElementById('selectedDateTime').textContent = 'None';

        // Fetch available dates
        fetch(`get_available_dates.php?MedicId=${doctorId}&year=${new Date().getFullYear()}&month=${new Date().getMonth() + 1}`)
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    showToast(data.error, false);
                    return;
                }

                // Store available dates and slots
                availableDates = data.dates;
                availableSlots = data.slots;

                // Initialize Flatpickr
                if (flatpickrInstance) flatpickrInstance.destroy();
                flatpickrInstance = flatpickr('#appointmentDate', {
                    enable: availableDates,
                    dateFormat: 'Y-m-d',
                    minDate: 'today',
                    onChange: (selectedDates, dateStr) => {
                        // Populate time slots
                        const timeSlotsContainer = document.getElementById('timeSlots');
                        timeSlotsContainer.innerHTML = '';
                        if (availableSlots[dateStr] && availableSlots[dateStr].length > 0) {
                            availableSlots[dateStr].forEach(time => {
                                const btn = document.createElement('button');
                                btn.type = 'button';
                                btn.className = 'btn btn-outline-primary time-slot-btn';
                                btn.textContent = time;
                                btn.dataset.time = time;
                                timeSlotsContainer.appendChild(btn);

                                btn.addEventListener('click', () => {
                                    document.querySelectorAll('.time-slot-btn').forEach(b => b.classList.remove('selected'));
                                    btn.classList.add('selected');
                                    document.getElementById('startTime').value = time;
                                    document.getElementById('selectedDateTime').textContent = `${dateStr} at ${time}`;
                                });
                            });
                        } else {
                            timeSlotsContainer.innerHTML = '<div class="text-muted">No time slots available</div>';
                        }
                    }
                });
            })
            .catch(error => {
                console.error('Error fetching dates:', error);
                showToast('Failed to load available dates.', false);
            });
    });
});

// Handle form submission
document.getElementById('appointmentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const submitBtn = document.getElementById('submitBtn');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span> Booking...';

    const formData = new FormData(this);
    const data = Object.fromEntries(formData);

    fetch('submit_appointment.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showToast('Appointment booked successfully!');
                const modal = bootstrap.Modal.getInstance(document.getElementById('bookAppointmentModal'));
                modal.hide();
                this.reset();
                document.getElementById('selectedDateTime').textContent = 'None';
                document.getElementById('timeSlots').innerHTML = '';
                if (flatpickrInstance) flatpickrInstance.destroy();
            } else {
                showToast(result.error || 'Failed to book appointment.', false);
            }
        })
        .catch(error => {
            console.error('Error submitting appointment:', error);
            showToast('Failed to book appointment.', false);
        })
        .finally(() => {
            submitBtn.disabled = false;
            submitBtn.innerHTML = 'Confirm Appointment';
        });
});
</script>
</body>
</html>