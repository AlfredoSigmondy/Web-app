<?php
session_start();
header('Content-Type: application/json');
include_once __DIR__ . '/database/conection_db.php';

// Get patient ID from session
$patient_id = isset($_SESSION['patient_id']) ? $_SESSION['patient_id'] : null;

if (!$patient_id) {
    echo json_encode(['error' => 'Please log in to book an appointment']);
    exit;
}

// Get input data
$input = json_decode(file_get_contents('php://input'), true);
$doctor_id = $input['doctor_id'] ?? null;
$patient_name = $input['patient_name'] ?? '';
$notes = $input['notes'] ?? '';
$appointment_date = $input['appointment_date'] ?? null;
$start_time = $input['start_time'] ?? null;

if (!$doctor_id || !$patient_name || !$notes || !$appointment_date || !$start_time) {
    echo json_encode(['error' => 'All fields are required']);
    exit;
}

// Validate date
try {
    $date = new DateTime($appointment_date);
    if ($date < new DateTime('today')) {
        echo json_encode(['error' => 'Cannot book appointments in the past']);
        exit;
    }
} catch (Exception $e) {
    echo json_encode(['error' => 'Invalid date format']);
    exit;
}

// Calculate end_time (30 minutes after start_time)
try {
    $start = new DateTime($start_time);
    $end = (clone $start)->modify('+30 minutes');
    $end_time = $end->format('H:i');
} catch (Exception $e) {
    echo json_encode(['error' => 'Invalid time format']);
    exit;
}

// Check if slot is available
$stmt_check = $conn->prepare("SELECT COUNT(*) FROM appointments 
    WHERE doctor_id = ? AND appointment_date = ? AND start_time = ? AND status IN ('Pending', 'Scheduled')");
$stmt_check->bind_param("iss", $doctor_id, $appointment_date, $start_time);
$stmt_check->execute();
if ($stmt_check->get_result()->fetch_row()[0] > 0) {
    echo json_encode(['error' => 'This slot is no longer available']);
    exit;
}

// Insert appointment
$stmt = $conn->prepare("INSERT INTO appointments (doctor_id, patient_id, appointment_date, start_time, end_time, status, notes, created_at, updated_at) 
    VALUES (?, ?, ?, ?, ?, 'Pending', ?, NOW(), NOW())");
$stmt->bind_param("iissss", $doctor_id, $patient_id, $appointment_date, $start_time, $end_time, $notes);
if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['error' => 'Failed to book appointment']);
}
$stmt->close();
$conn->close();
?>