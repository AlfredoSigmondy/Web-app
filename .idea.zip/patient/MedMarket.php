<?php
// filepath: c:\Users\Ronian\OneDrive\Desktop\EMed\patient\MedMarket.php
session_start();
include_once __DIR__ . '../../database/conection_db.php';
include_once __DIR__ . '../MedMarketController.php';

// Function to get medicines with proper image paths
function getMedicinesWithImages($conn) {
    $medicines = [];
    $result = $conn->query("SELECT m.*, c.name as category FROM medicines m LEFT JOIN categories c ON m.category_id = c.id");
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Ensure image path is properly formatted
            if (!empty($row['image_path'])) {
                // If path doesn't start with / or http, prepend base path
                if (strpos($row['image_path'], '/') !== 0 && strpos($row['image_path'], 'http') !== 0) {
                    $row['image_path'] = '/Images/' . $row['image_path'];
                }
            } else {
                // Default image if none is set
                $row['image_path'] = '/Images/default-medicine.jpg';
            }
            $medicines[] = $row;
        }
    }
    return $medicines;
}

$categories = getCategories($conn);
$medicines = getMedicinesWithImages($conn);
$buyer_name = $_SESSION['Username'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>MedMarket - eMedConnect</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet"/>
    <style>
      .main-content {
        padding: 20px 0 0 0;
        min-height: 100vh;
      }
      .top-bar-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 2rem;
        margin-bottom: 1.5rem;
        margin-right: 0;
        margin-left: 0;
      }
      .search-bar-group {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        flex: 1 1 auto;
      }
      .cart-icon, .notif-icon {
        position: relative;
        z-index: 1;
        cursor: pointer;
        display: inline-block;
        margin-left: 1rem;
      }
      .cart-icon img { height: 36px; }
      .notif-icon { font-size: 2rem; color: #43c97e; }
      .notif-toast {
        position: fixed;
        top: 90px;
        right: 40px;
        z-index: 2000;
        min-width: 250px;
      }
      .medicine-card {
        transition: box-shadow 0.2s, transform 0.2s;
        cursor: pointer;
        min-width: 220px;
        max-width: 260px;
        width: 100%;
        margin: 0 auto 10px;
        border-radius: 1.2rem;
        background: #f8fff8;
        overflow: hidden;
        box-shadow: 0 2px 8px #e6f5ea;
      }
      .medicine-card:hover {
        box-shadow: 0 0 16px #43c97e44;
        transform: scale(1.05);
        background: #eaffea;
      }
      .medicine-img {
        height: 100px;
        object-fit: contain;
        border-radius: 1rem 1rem 0 0;
        background: #fff;
        margin-bottom: 0.5rem;
        padding: 10px;
      }
      .img-placeholder {
        height: 100px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #f0f0f0;
        border-radius: 1rem 1rem 0 0;
        margin-bottom: 0.5rem;
      }
      .card-body {
        padding: 1rem !important;
      }
      .card-title {
        font-size: 1.1rem;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        font-weight: 600;
      }
    </style>
</head>
<body>
<div class="container-fluid">
  <div class="row flex-nowrap">
    <!-- Sidebar -->
    <div class="col-auto d-none d-lg-block p-0">
      <?php include_once __DIR__ . '/../SideBar/Sidebar.php'; ?>
    </div>

    <!-- Main Content -->
    <div class="col main-content">
      <!-- Top Bar: Search, Cart, Notification -->
      <div class="top-bar-row">
        <div class="search-bar-group">
          <input id="searchBar" type="text" class="form-control" style="width: 200px" placeholder="Search..."/>
          <select id="categoryFilter" class="form-select w-auto">
            <option value="">All Categories</option>
            <?php foreach ($categories as $cat): ?>
            <option value="<?= htmlspecialchars($cat['name']) ?>"><?= htmlspecialchars($cat['name']) ?></option>
            <?php endforeach; ?>
          </select>
          <button class="btn btn-success" onclick="filterMedicines()">Filter</button>
        </div>
        <div>
          <span class="cart-icon" onclick="showCart()" title="View Cart">
            <img src="/Images/shopping-cart.png" alt="Cart" />
            <span class="badge bg-danger" id="cartCount" style="position: absolute; top: -10px; right: -10px">0</span>
          </span>
          <span class="notif-icon" id="notifBell" title="Notifications">
            <i class="bi bi-bell-fill"></i>
          </span>
        </div>
      </div>
      <div id="notifToast" class="notif-toast"></div>

      <div class="container py-4">
    <div class="row g-4 justify-content-center" id="medicineGrid" style="max-width:1400px;margin:0 auto;">
        <?php foreach ($medicines as $med): 
            // Generate image filename based on medicine name
            $imageName = strtolower(str_replace(' ', '-', $med['name'])) . '.jpg';
            $imagePath = '/Images/' . $imageName;
            $defaultImage = '/Images/default-medicine.jpg';
        ?>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-flex">
                <div class="card medicine-card h-100 shadow-sm border-0 flex-fill"
                     data-med='<?= htmlspecialchars(json_encode($med), ENT_QUOTES, 'UTF-8') ?>'
                     onclick="showMedicineModal(this)">
                    <img src="<?= $imagePath ?>" 
                         class="card-img-top medicine-img mt-2" 
                         alt="<?= htmlspecialchars($med['name']) ?>"
                         onerror="this.onerror=null;this.src='<?= $defaultImage ?>';" />
                    <div class="card-body p-2 text-center">
                        <h6 class="card-title mb-1"><?= htmlspecialchars($med['name']) ?></h6>
                        <div class="mb-1"><span class="badge bg-info"><?= htmlspecialchars($med['category']) ?></span></div>
                        <div class="mb-1" style="font-size:0.9em;">Grams: <?= htmlspecialchars($med['grams'] ?? '-') ?></div>
                        <div class="fw-bold text-success" style="font-size:1.1em;">₱<?= number_format($med['price'], 2) ?></div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php include_once __DIR__ . '/../SideBar_Right/SidebarRight.html'; ?>
    

<!-- Medicine Modal -->
<div class="modal fade" id="medicineModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content modal-animate">
      <form onsubmit="return handleBuy(event)">
        <div class="modal-header">
          <h5 class="modal-title">Medicine Details</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <img id="modalImg" src="" class="img-fluid mb-2" onerror="this.onerror=null;this.src='/Images/default-medicine.jpg';" />
          <h5 id="modalName"></h5>
          <div><span class="badge bg-info" id="modalCategory"></span></div>
          <div id="modalGrams"></div>
          <div class="fw-bold text-success" id="modalPrice"></div>
          <div class="mb-2">
            <label for="buyerName" class="form-label">Your Name</label>
            <input type="text" class="form-control" id="buyerName" required value="<?= htmlspecialchars($buyer_name) ?>" />
          </div>
          <div class="mb-2">
            <label for="deliveryLocation" class="form-label">Delivery Location</label>
            <input type="text" class="form-control" id="deliveryLocation" readonly required />
            <button type="button" class="btn btn-link p-0" onclick="getLocation()">Use My Current Location</button>
            <div id="map"></div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" onclick="addToCart()">Add to Cart</button>
          <button type="submit" class="btn btn-success">Buy Now</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Cart Modal -->
<div class="modal fade" id="cartModal" tabindex="-1" aria-labelledby="cartModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="cartModalLabel">Your Cart</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="cartBody">Your cart is empty.</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
let selectedMedicine = null, cart = [], marker, map, notifTimeout;

function showMedicineModal(cardElement) {
  const med = JSON.parse(cardElement.getAttribute("data-med"));
  selectedMedicine = med;
  document.getElementById("modalImg").src = med.image_path;
  document.getElementById("modalName").textContent = med.name;
  document.getElementById("modalCategory").textContent = med.category;
  document.getElementById("modalGrams").textContent = "Grams: " + (med.grams || "-");
  document.getElementById("modalPrice").textContent = "₱" + med.price;
  document.getElementById("deliveryLocation").value = "";
  document.getElementById("buyerName").value = "<?= htmlspecialchars($buyer_name) ?>";
  document.getElementById("map").innerHTML = "";
  new bootstrap.Modal(document.getElementById("medicineModal")).show();
}

function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        let latLng = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        map = new google.maps.Map(document.getElementById("map"), {
          center: latLng,
          zoom: 15,
        });
        marker = new google.maps.Marker({ position: latLng, map: map });
        document.getElementById("deliveryLocation").value = `Lat: ${latLng.lat.toFixed(5)}, Lng: ${latLng.lng.toFixed(5)}`;
      },
      () => alert("Unable to fetch location")
    );
  } else alert("Geolocation not supported");
}

function addToCart() {
  if (!selectedMedicine) return;
  cart.push(selectedMedicine);
  updateCartCount();
  showNotification("Added to cart!", "success");
}

function updateCartCount() {
  document.getElementById("cartCount").textContent = cart.length;
}

function showCart() {
  const cartBody = document.getElementById("cartBody");
  if (cart.length === 0) {
    cartBody.textContent = "Your cart is empty.";
  } else {
    cartBody.innerHTML = "";
    cart.forEach((med, i) => {
      const div = document.createElement("div");
      div.className = "border-bottom py-2 d-flex justify-content-between align-items-center";
      div.innerHTML = `
        <div>
          <strong>${med.name}</strong> - ₱${med.price}
          ${med.image_path ? `<img src="${med.image_path}" style="height: 40px; width: auto;" onerror="this.style.display='none'">` : ''}
        </div>
        <div>
          <button class="btn btn-sm btn-success me-1" onclick="buyFromCart(${i});event.stopPropagation();">Buy Now</button>
          <button class="btn btn-sm btn-danger" onclick="removeFromCart(${i});event.stopPropagation();">Remove</button>
        </div>
      `;
      cartBody.appendChild(div);
    });
  }
  new bootstrap.Modal(document.getElementById("cartModal")).show();
}

function buyFromCart(index) {
  const med = cart[index];
  if (!med.lemonsqueezy_checkout_id) {
    showNotification("This item is not configured for purchase.", "info");
    return;
  }
  window.open(med.lemonsqueezy_checkout_id, "_blank");
  showNotification("Redirected to Lemon Squeezy.", "info");
}

function removeFromCart(index) {
  cart.splice(index, 1);
  updateCartCount();
  showCart();
  showNotification("Item removed from cart", "info");
}

function handleBuy(event) {
  event.preventDefault();
  if (!selectedMedicine) return false;
  const buyerName = document.getElementById("buyerName").value.trim();
  const location = document.getElementById("deliveryLocation").value.trim();
  if (!buyerName || !location) {
    alert("Please fill buyer name and delivery location.");
    return false;
  }
  if (!selectedMedicine.lemonsqueezy_checkout_id) {
    showNotification("This item is not configured for purchase.", "info");
    return false;
  }
  window.open(selectedMedicine.lemonsqueezy_checkout_id, "_blank");
  showNotification("Redirected to Lemon Squeezy.", "info");
  bootstrap.Modal.getInstance(document.getElementById("medicineModal")).hide();
  return false;
}

// Notification inside bell, disappears after 10s
function showNotification(msg, type = "info") {
  const notifBell = document.getElementById("notifBell");

  // Remove existing notification if present
  const existingToast = notifBell.querySelector(".notif-toast");
  if (existingToast) {
    existingToast.remove();
    clearTimeout(notifTimeout);
  }

  // Create toast element inside bell icon
  const toast = document.createElement("div");
  toast.className = `notif-toast toast align-items-center text-bg-${type === "success" ? "success" : "primary"} border-0 show`;
  toast.style.position = "absolute";
  toast.style.top = "30px";
  toast.style.right = "0";
  toast.style.minWidth = "200px";
  toast.style.zIndex = "1050";

  toast.innerHTML = `
    <div class="d-flex">
      <div class="toast-body" style="font-size: 0.9rem;">${msg}</div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" aria-label="Close"></button>
    </div>
  `;

  notifBell.style.position = "relative";
  notifBell.appendChild(toast);

  toast.querySelector("button.btn-close").onclick = () => {
    toast.remove();
    clearTimeout(notifTimeout);
  };

  notifTimeout = setTimeout(() => {
    toast.remove();
  }, 10000);
}

// Filter medicines based on search and category
function filterMedicines() {
  const searchText = document.getElementById("searchBar").value.toLowerCase();
  const category = document.getElementById("categoryFilter").value.toLowerCase();
  const cards = document.querySelectorAll("#medicineGrid .medicine-card");

  cards.forEach(card => {
    const med = JSON.parse(card.getAttribute("data-med"));
    const matchSearch = med.name.toLowerCase().includes(searchText);
    const matchCategory = category === "" || med.category.toLowerCase() === category;
    card.parentElement.style.display = (matchSearch && matchCategory) ? "block" : "none";
  });
}

document.getElementById("searchBar").addEventListener("input", filterMedicines);
document.getElementById("categoryFilter").addEventListener("change", filterMedicines);
</script>
</body>
</html>